import React, {useEffect, useState} from 'react';
import axios from 'axios';

export default function App(){
  const [courses, setCourses] = useState([]);
  const [title, setTitle] = useState('');
  const [desc, setDesc] = useState('');

  useEffect(()=> {
    fetchCourses();
  }, []);

  async function fetchCourses(){
    try {
      const res = await axios.get('http://localhost:5000/api/courses');
      setCourses(res.data);
    } catch (err) {
      console.error(err);
    }
  }

  async function addCourse(e){
    e.preventDefault();
    try {
      await axios.post('http://localhost:5000/api/courses', { title, description: desc });
      setTitle(''); setDesc('');
      fetchCourses();
    } catch (err) {
      console.error(err);
    }
  }

  return (
    <div style={{ padding: 24, fontFamily: 'Arial, sans-serif' }}>
      <h1>SkillForge — Full Stack</h1>
      <form onSubmit={addCourse} style={{ marginBottom: 16 }}>
        <input placeholder="Course title" value={title} onChange={e=>setTitle(e.target.value)} required />
        <input placeholder="Description" value={desc} onChange={e=>setDesc(e.target.value)} style={{ marginLeft:8 }} />
        <button type="submit" style={{ marginLeft:8 }}>Add</button>
      </form>

      <h2>Courses</h2>
      <ul>
        {courses.length === 0 ? <li>No courses yet — add one!</li> : courses.map(c=>(
          <li key={c._id || c.title}><strong>{c.title}</strong> — {c.description}</li>
        ))}
      </ul>
    </div>
  );
}
