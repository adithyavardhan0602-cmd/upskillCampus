# SkillForge — Full Stack Development (Project Scaffold)

This repository contains a minimal full-stack scaffold for the **SkillForge** project.

## Structure

- backend/ — Node.js + Express server with Mongoose models
- frontend/ — Minimal React (Vite) frontend that connects to backend
- SkillForge_Report.pdf — Project report (generated)

## Quick setup (local)

1. Backend:
   - `cd backend`
   - create `.env` from `.env.example` and set `MONGO_URI`
   - `npm install`
   - `npm run dev` (needs nodemon) or `npm start`

2. Frontend:
   - `cd frontend`
   - `npm install`
   - `npm run start` (requires Node >=16; uses Vite)

This setup assumes MongoDB is running locally at the URI in `.env`.

## Notes
- The backend exposes `/api/health` and `/api/courses` (GET/POST).
- The frontend expects backend at `http://localhost:5000`.
- For production, configure CORS, environment variables, and a production build for frontend.
